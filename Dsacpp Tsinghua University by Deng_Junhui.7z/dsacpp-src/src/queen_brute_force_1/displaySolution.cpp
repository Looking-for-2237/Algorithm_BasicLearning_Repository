/******************************************************************************************
 * Data Structures in C++
 * ISBN: 7-302-33064-6 & 7-302-33065-3 & 7-302-29652-2 & 7-302-26883-3
 * Junhui DENG, deng@tsinghua.edu.cn
 * Computer Science & Technology, Tsinghua University
 * Copyright (c) 2003-2024.
 ******************************************************************************************/

#include "queen.h"

void displaySolution ( int* solu, int n ) { //���n*n�Ŀ��в���
   ( Step == runMode ) ? system ( "cls" ) : printf ( "--\n" );
   for ( int i = 0; i < n; i++ ) {
      for ( int j = 0; j < n; j++ ) {
         printf ( ( j == solu[i] ) ? "��" : "[]" );
      }
      printf ( "\n" );
   }
   if ( Step == runMode ) {
      cout  << nSolu << " solution(s) found after " << nCheck << " check(s)\a";
      getchar();
   } else
      printf ( "\n" );
}